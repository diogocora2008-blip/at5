// Gráfico da página Dados (Chart.js)
document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("hiringChart");
  if (canvas && typeof Chart !== "undefined") {
    new Chart(canvas, {
      type: "bar",
      data: {
        labels: ["Júnior", "Sênior"],
        datasets: [{
          label: "Variação anual reportada (%)",
          data: [9, 19],
          backgroundColor: ["#9278ff", "#4fc9b7"],
          borderRadius: 10,
          maxBarThickness: 100
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: "#e7e7f3" } },
          tooltip: { callbacks: { label: (context) => `${context.raw > 0 ? "+" : ""}${context.raw}%` } }
        },
        scales: {
          x: { ticks: { color: "#d0d1e1" }, grid: { display: false } },
          y: { beginAtZero: true, ticks: { color: "#d0d1e1", callback: (value) => `${value}%` }, grid: { color: "rgba(200,200,230,.12)" } }
        }
      }
    });
  }

  // Simulador de preparação para o primeiro emprego
  const form = document.getElementById("readinessForm");
  if (!form) return;
  const checks = Array.from(form.querySelectorAll('input[type="checkbox"]'));
  const score = document.getElementById("score");
  const bar = document.getElementById("scoreBar");
  const progress = document.querySelector(".custom-progress");
  const title = document.getElementById("resultTitle");
  const text = document.getElementById("resultText");
  const steps = document.getElementById("nextSteps");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const total = checks.filter((check) => check.checked).length;
    score.innerHTML = `${total}<span>/6</span>`;
    bar.style.width = `${(total / checks.length) * 100}%`;
    progress.setAttribute("aria-valuenow", String(total));
    steps.replaceChildren();

    let heading;
    let message;
    let suggestions;
    if (total <= 2) {
      heading = "Construa sua base";
      message = "Você está no começo do caminho. Isso é normal: escolha poucas metas e avance de forma consistente.";
      suggestions = ["Pratique HTML, CSS, JavaScript e lógica.", "Crie uma página simples e publique no GitHub.", "Estude em etapas pequenas e peça feedback quando puder."];
    } else if (total <= 4) {
      heading = "Você já tem pontos de partida";
      message = "Agora vale transformar seus conhecimentos em evidências que recrutadores e colegas consigam avaliar.";
      suggestions = ["Melhore um projeto e escreva um README claro.", "Treine explicar seu código sem depender da IA.", "Revise os itens que ainda não marcou e faça um plano semanal."];
    } else {
      heading = "Continue comprovando suas habilidades";
      message = "Você marcou várias práticas importantes. O próximo passo é exercitá-las em situações parecidas com as do trabalho.";
      suggestions = ["Faça simulados de entrevista e exercícios técnicos.", "Peça revisão de código e corrija os pontos encontrados.", "Procure estágios e vagas compatíveis com sua experiência."];
    }
    title.textContent = heading;
    text.textContent = message;
    suggestions.forEach((suggestion) => {
      const item = document.createElement("li");
      item.textContent = suggestion;
      steps.appendChild(item);
    });
  });

  form.addEventListener("reset", () => {
    window.setTimeout(() => {
      score.innerHTML = '—<span>/6</span>';
      bar.style.width = "0%";
      progress.setAttribute("aria-valuenow", "0");
      title.textContent = "Responda ao simulador";
      text.textContent = "Marque as atividades que você já consegue demonstrar e clique no botão para receber sugestões.";
      steps.replaceChildren();
    }, 0);
  });
});
