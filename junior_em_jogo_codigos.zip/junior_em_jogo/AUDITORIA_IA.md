# Auditoria de uso de IA — Júnior em Jogo

> Preencha este documento com o que realmente aconteceu durante o desenvolvimento. Não copie exemplos como se fossem testes executados.

## Iteração 1 — Estrutura HTML e Bootstrap

- **Ferramenta utilizada:** [preencher]
- **Prompt completo utilizado:** [colar o prompt]
- **Trecho inicial gerado pela IA:** [colar o trecho relevante]
- **Auditoria crítica:** verificar semântica HTML, hierarquia de títulos, links, navegação responsiva, acessibilidade e uso do Bootstrap.
- **Correções feitas manualmente:** [descrever e justificar]
- **Testes realizados:** [navegação, celular, teclado, etc.]

## Iteração 2 — Simulador em JavaScript

- **Ferramenta utilizada:** [preencher]
- **Prompt completo utilizado:** [colar o prompt]
- **Trecho inicial gerado pela IA:** [colar o trecho relevante]
- **Auditoria crítica:** verificar cálculo da pontuação, validação, mensagens, acessibilidade, eventos e comportamento ao limpar respostas.
- **Correções feitas manualmente:** [descrever e justificar]
- **Testes realizados:** [marcar 0, 1, metade e todos os itens; limpar formulário]

## Iteração 3 — Gráfico com Chart.js

- **Ferramenta utilizada:** [preencher]
- **Prompt completo utilizado:** [colar o prompt]
- **Trecho inicial gerado pela IA:** [colar o trecho relevante]
- **Auditoria crítica:** conferir a origem dos dados, unidades, rótulos, leitura em telas pequenas e se o gráfico não sugere conclusões que os dados não sustentam.
- **Correções feitas manualmente:** [descrever e justificar]
- **Testes realizados:** [carregamento do gráfico, legenda, tooltip e celular]

## Reflexão final

- O que aprendemos sobre o código?
- Quais sugestões da IA foram alteradas ou rejeitadas?
- Como verificamos que os dados e as funcionalidades funcionam?
